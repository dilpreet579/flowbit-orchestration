import { OrchestrationDashboard } from "@/components/orchestration-dashboard"

export default function Home() {
  return <OrchestrationDashboard />
}
